#ifndef __STRSEP_H
#define __STRSEP_H

char *strseparate(register char **stringp, register const char *delim);

#endif
